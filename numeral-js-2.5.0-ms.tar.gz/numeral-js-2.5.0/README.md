# numeral.js

[![Build Status](https://travis-ci.org/elastic/numeral-js.svg?branch=master)](https://travis-ci.org/elastic/numeral-js)

A javascript library for formatting and manipulating numbers. Forked from https://github.com/adamwdraper/Numeral-js

# Acknowlegements

Numeral.js, while less complex, was inspired by and heavily borrowed from [Moment.js](http://momentjs.com)


# License

Numeral.js is freely distributable under the terms of the MIT license. See the [LICENSE](LICENSE) file.
